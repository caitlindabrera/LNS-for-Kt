module EqdepFacts where

import qualified Prelude

internal_eq_rew_r_dep :: a1 -> a1 -> a2 -> a2
internal_eq_rew_r_dep _ _ hC =
  hC

