module Gen_tacs where

import qualified Prelude
import qualified Datatypes

type Coq_rel w = Datatypes.Coq_prod w w

